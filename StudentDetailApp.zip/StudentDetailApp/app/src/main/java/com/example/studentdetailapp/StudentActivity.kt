package com.example.studentdetailapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class StudentActivity : AppCompatActivity() {

    lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student)

        db = DBHelper(this)

        val etName = findViewById<EditText>(R.id.etName)
        val etRollNo = findViewById<EditText>(R.id.etRollNo)
        val etCourse = findViewById<EditText>(R.id.etCourse)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnView = findViewById<Button>(R.id.btnView)
        val btnDelete = findViewById<Button>(R.id.btnDelete)
        val btnUpdate = findViewById<Button>(R.id.btnUpdate)
        val listStudents = findViewById<ListView>(R.id.listStudents)

        btnSave.setOnClickListener {
            val name = etName.text.toString()
            val rollText = etRollNo.text.toString()
            val course = etCourse.text.toString()
            val email = etEmail.text.toString()

            if(name.isEmpty() || rollText.isEmpty() || course.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show()
            } else {
                val rollNo = rollText.toInt()
                val result = db.insertStudent(rollNo, name, course, email)
                Toast.makeText(this, if(result) "Student Saved!" else "Error Saving!", Toast.LENGTH_SHORT).show()
            }
        }

        btnView.setOnClickListener {
            val list = db.getAllStudents()
            val adapter = ArrayAdapter(this, R.layout.list_item_student, R.id.tvStudentItem, list)
            listStudents.adapter = adapter
        }

        btnDelete.setOnClickListener {
            val rollText = etRollNo.text.toString()
            if(rollText.isEmpty()) {
                Toast.makeText(this, "Enter Roll No to Delete!", Toast.LENGTH_SHORT).show()
            } else {
                val result = db.deleteStudent(rollText.toInt())
                Toast.makeText(this, if(result) "Student Deleted!" else "Delete Failed!", Toast.LENGTH_SHORT).show()
            }
        }

        btnUpdate.setOnClickListener {
            val name = etName.text.toString()
            val rollText = etRollNo.text.toString()
            val course = etCourse.text.toString()
            val email = etEmail.text.toString()

            if(name.isEmpty() || rollText.isEmpty() || course.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show()
            } else {
                val result = db.updateStudent(rollText.toInt(), name, course, email)
                Toast.makeText(this, if(result) "Record Updated!" else "Update Failed!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
