package com.example.studentdetailapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, "StudentDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE student(rollNo INTEGER PRIMARY KEY, name TEXT, course TEXT, email TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS student")
        onCreate(db)
    }

    fun insertStudent(rollNo: Int, name: String, course: String, email: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("rollNo", rollNo)
        values.put("name", name)
        values.put("course", course)
        values.put("email", email)
        return db.insert("student", null, values) != -1L
    }

    fun updateStudent(rollNo: Int, name: String, course: String, email: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("course", course)
        values.put("email", email)
        return db.update("student", values, "rollNo=?", arrayOf(rollNo.toString())) > 0
    }

    fun deleteStudent(rollNo: Int): Boolean {
        val db = writableDatabase
        return db.delete("student", "rollNo=?", arrayOf(rollNo.toString())) > 0
    }

    fun getAllStudents(): ArrayList<String> {
        val list = ArrayList<String>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM student", null)
        while(cursor.moveToNext()) {
            val roll = cursor.getInt(0)
            val name = cursor.getString(1)
            val course = cursor.getString(2)
            val email = cursor.getString(3)
            list.add("Roll No: $roll\nName: $name\nCourse: $course\nEmail: $email")
        }
        cursor.close()
        return list
    }
}
