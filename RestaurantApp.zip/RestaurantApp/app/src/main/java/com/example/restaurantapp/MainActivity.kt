package com.example.restaurantapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DBHelper(this)

        val etOrderID = findViewById<EditText>(R.id.etOrderID)
        val etCustomerName = findViewById<EditText>(R.id.etCustomerName)
        val etDishName = findViewById<EditText>(R.id.etDishName)
        val etQuantity = findViewById<EditText>(R.id.etQuantity)
        val etPrice = findViewById<EditText>(R.id.etPrice)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnView = findViewById<Button>(R.id.btnView)
        val btnUpdate = findViewById<Button>(R.id.btnUpdate)
        val btnDelete = findViewById<Button>(R.id.btnDelete)

        btnAdd.setOnClickListener {
            try {
                val id = etOrderID.text.toString().toInt()
                val name = etCustomerName.text.toString()
                val dish = etDishName.text.toString()
                val qty = etQuantity.text.toString().toInt()
                val price = etPrice.text.toString().toDouble()

                val result = db.insertOrder(id, name, dish, qty, price)
                Toast.makeText(this, if (result) "✅ Order Added!" else "❌ Failed!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Enter all fields correctly!", Toast.LENGTH_SHORT).show()
            }
        }

        btnView.setOnClickListener {
            startActivity(Intent(this, OrderSummaryActivity::class.java))
        }

        btnUpdate.setOnClickListener {
            try {
                val id = etOrderID.text.toString().toInt()
                val name = etCustomerName.text.toString()
                val dish = etDishName.text.toString()
                val qty = etQuantity.text.toString().toInt()
                val price = etPrice.text.toString().toDouble()

                val result = db.updateOrder(id, name, dish, qty, price)
                Toast.makeText(this, if (result) "🔄 Order Updated!" else "❌ Update Failed!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Enter valid details!", Toast.LENGTH_SHORT).show()
            }
        }

        btnDelete.setOnClickListener {
            try {
                val id = etOrderID.text.toString().toInt()
                val result = db.deleteOrder(id)
                Toast.makeText(this, if (result) "🗑️ Order Deleted!" else "❌ Delete Failed!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Enter valid Order ID!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
