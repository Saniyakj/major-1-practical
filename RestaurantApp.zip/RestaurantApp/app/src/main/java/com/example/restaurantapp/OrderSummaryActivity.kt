package com.example.restaurantapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity

class OrderSummaryActivity : AppCompatActivity() {

    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_summary)

        db = DBHelper(this)
        val gridOrders = findViewById<GridView>(R.id.gridOrders)

        val orders = db.getAllOrders()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, orders)
        gridOrders.adapter = adapter
    }
}
