package com.example.restaurantapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, "RestaurantDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE orders(" +
                    "orderID INTEGER PRIMARY KEY," +
                    "customerName TEXT," +
                    "dishName TEXT," +
                    "quantity INTEGER," +
                    "price REAL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS orders")
        onCreate(db)
    }

    fun insertOrder(id: Int, name: String, dish: String, qty: Int, price: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("orderID", id)
            put("customerName", name)
            put("dishName", dish)
            put("quantity", qty)
            put("price", price)
        }
        val result = db.insert("orders", null, values)
        db.close()
        return result != -1L
    }

    fun updateOrder(id: Int, name: String, dish: String, qty: Int, price: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("customerName", name)
            put("dishName", dish)
            put("quantity", qty)
            put("price", price)
        }
        val result = db.update("orders", values, "orderID=?", arrayOf(id.toString()))
        db.close()
        return result > 0
    }

    fun deleteOrder(id: Int): Boolean {
        val db = writableDatabase
        val result = db.delete("orders", "orderID=?", arrayOf(id.toString()))
        db.close()
        return result > 0
    }

    fun getAllOrders(): ArrayList<String> {
        val db = readableDatabase
        val list = ArrayList<String>()
        val cursor = db.rawQuery("SELECT * FROM orders", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(0)
                val name = cursor.getString(1)
                val dish = cursor.getString(2)
                val qty = cursor.getInt(3)
                val price = cursor.getDouble(4)
                list.add("ID: $id\n$name ordered $qty x $dish\n₹$price each")
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }
}
