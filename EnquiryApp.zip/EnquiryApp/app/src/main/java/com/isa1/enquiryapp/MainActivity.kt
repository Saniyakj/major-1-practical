package com.isa1.enquiryapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinnerCountry: Spinner = findViewById(R.id.spinnerCountry)
        val spinnerState: Spinner = findViewById(R.id.spinnerState)
        val spinnerDistrict: Spinner = findViewById(R.id.spinnerDistrict)
        val spinnerCentre: Spinner = findViewById(R.id.spinnerCentre)
        val btnSelect: Button = findViewById(R.id.btnSelectCentre)

        // Dropdown lists
        val countries = listOf("Select Country", "India", "USA", "UK")
        val states = listOf("Select State", "Karnataka", "California", "London")
        val districts = listOf("Select District", "Bangalore", "LA", "Westminster")
        val centres = listOf("Select Centre", "Centre A", "Centre B", "Centre C")

        spinnerCountry.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, countries)
        spinnerState.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, states)
        spinnerDistrict.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, districts)
        spinnerCentre.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, centres)

        btnSelect.setOnClickListener {
            val country = spinnerCountry.selectedItem.toString()
            val state = spinnerState.selectedItem.toString()
            val district = spinnerDistrict.selectedItem.toString()
            val centre = spinnerCentre.selectedItem.toString()

            Toast.makeText(this, "Selected: $country → $state → $district → $centre", Toast.LENGTH_SHORT).show()
        }
    }
}
