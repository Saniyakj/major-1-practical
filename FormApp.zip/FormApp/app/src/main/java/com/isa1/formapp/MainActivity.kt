package com.isa1.formapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        val name = findViewById<EditText>(R.id.editName)
        val male = findViewById<RadioButton>(R.id.radioMale)
        val female = findViewById<RadioButton>(R.id.radioFemale)
        val other = findViewById<RadioButton>(R.id.radioOther)
        val weight = findViewById<EditText>(R.id.editWeight)
        val height = findViewById<EditText>(R.id.editHeight)
        val goal = findViewById<EditText>(R.id.editGoal)
        val age = findViewById<EditText>(R.id.editAge)
        val phone = findViewById<EditText>(R.id.editPhone)
        val address = findViewById<EditText>(R.id.editAddress)
        val checkBox = findViewById<CheckBox>(R.id.checkBox)
        val submit = findViewById<Button>(R.id.btnSubmit)

        submit.setOnClickListener {
            if (!checkBox.isChecked) {
                Toast.makeText(this, "Please accept membership rules!", Toast.LENGTH_SHORT).show()
            } else {
                val gender = when {
                    male.isChecked -> "Male"
                    female.isChecked -> "Female"
                    else -> "Other"
                }

                val msg = """
                    Name: ${name.text}
                    Gender: $gender
                    Weight: ${weight.text}
                    Height: ${height.text}
                    Goal Weight: ${goal.text}
                    Age: ${age.text}
                    Phone: ${phone.text}
                    Address: ${address.text}
                """.trimIndent()

                Toast.makeText(this, "Form Submitted:\n$msg", Toast.LENGTH_LONG).show()

                // Clear form after submission
                name.text.clear()
                male.isChecked = false
                female.isChecked = false
                other.isChecked = false
                weight.text.clear()
                height.text.clear()
                goal.text.clear()
                age.text.clear()
                phone.text.clear()
                address.text.clear()
                checkBox.isChecked = false
            }
        }
    }
}
