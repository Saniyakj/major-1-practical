package com.example.college57


import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var nameInput: EditText
    private lateinit var greetButton: Button
    private lateinit var greetingText: TextView
    private lateinit var exitButton: Button

    private val quotes = listOf(
        "Education is the most powerful weapon which you can use to change the world. – Nelson Mandela",
        "The future belongs to those who believe in the beauty of their dreams. – Eleanor Roosevelt",
        "The beautiful thing about learning is that nobody can take it away from you. – B.B. King",
        "Strive for progress, not perfection.",
        "Success is not final, failure is not fatal: It is the courage to continue that counts. – Winston Churchill"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameInput = findViewById(R.id.nameInput)
        greetButton = findViewById(R.id.greetButton)
        greetingText = findViewById(R.id.greetingText)
        exitButton = findViewById(R.id.exitButton)

        greetButton.setOnClickListener {
            val name = nameInput.text.toString().trim()
            if (name.isNotEmpty()) {
                greetingText.text = "Hello, $name! Welcome to our College Open Day!"
            } else {
                Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
            }
        }

        exitButton.setOnClickListener {
            val randomQuote = quotes.random()
            Toast.makeText(this, randomQuote, Toast.LENGTH_LONG).show()
            exitButton.postDelayed({ finishAffinity() }, 2500)
        }
    }
}
