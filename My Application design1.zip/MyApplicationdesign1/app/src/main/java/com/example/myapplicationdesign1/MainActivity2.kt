package com.example.myapplicationdesign1

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)  // This must match the XML filename

        val username = intent.getStringExtra("username") ?: "User"
        val textView = findViewById<TextView>(R.id.login)
        textView.text = "Welcome, $username!"
    }
}
