package com.example.myapplicationdesign1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var cancelButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usernameEditText = findViewById(R.id.Username)
        passwordEditText = findViewById(R.id.Password)
        loginButton = findViewById(R.id.button2)
        cancelButton = findViewById(R.id.button3)

        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            val passwordRegex = Regex("^[a-zA-Z0-9!@#\$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]{8,14}\$")

            when {
                username.isBlank() || password.isBlank() -> {
                    Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
                }

                !passwordRegex.matches(password) -> {
                    Toast.makeText(
                        this,
                        "Password must be 8-14 characters and can include letters, numbers, and special characters.",
                        Toast.LENGTH_LONG
                    ).show()
                }

                else -> {
                    val intent = Intent(this, MainActivity2::class.java)
                    intent.putExtra("username", username)
                    startActivity(intent)
                }
            }
        }

        cancelButton.setOnClickListener {
            usernameEditText.text.clear()
            passwordEditText.text.clear()
            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
        }
    }
}

