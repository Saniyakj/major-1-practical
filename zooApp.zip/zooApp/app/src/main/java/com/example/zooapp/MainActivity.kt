package com.example.zooapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
//import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val btnOpen = findViewById<Button>(R.id.btnOpenDB)
        btnOpen.setOnClickListener {
            val intent = Intent(this, AnimalActivity::class.java)
            startActivity(intent)
            Toast.makeText(this, "Navigated to Zoo Database Screen", Toast.LENGTH_SHORT).show()
        }
    }
}
