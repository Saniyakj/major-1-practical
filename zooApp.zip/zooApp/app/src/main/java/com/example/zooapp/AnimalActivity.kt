package com.example.zooapp

import android.os.Bundle
import android.widget.*
//import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class AnimalActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private lateinit var etId: EditText
    private lateinit var etName: EditText
    private lateinit var etSpecies: EditText
    private lateinit var etAge: EditText
    private lateinit var etEnclosure: EditText
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_animal)

        dbHelper = DBHelper(this)

        etId = findViewById(R.id.etAnimalId)
        etName = findViewById(R.id.etAnimalName)
        etSpecies = findViewById(R.id.etSpecies)
        etAge = findViewById(R.id.etAge)
        etEnclosure = findViewById(R.id.etEnclosure)
        listView = findViewById(R.id.listView)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnView = findViewById<Button>(R.id.btnView)
        val btnUpdate = findViewById<Button>(R.id.btnUpdate)
        val btnDelete = findViewById<Button>(R.id.btnDelete)

        btnAdd.setOnClickListener {
            val name = etName.text.toString()
            val species = etSpecies.text.toString()
            val age = etAge.text.toString()
            val enclosure = etEnclosure.text.toString()

            if (name.isNotEmpty() && species.isNotEmpty() && age.isNotEmpty() && enclosure.isNotEmpty()) {
                dbHelper.insertAnimal(name, species, age.toInt(), enclosure)
                Toast.makeText(this, "Animal Added", Toast.LENGTH_SHORT).show()
                clearFields()
            } else {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        btnView.setOnClickListener {
            val animals = dbHelper.getAllAnimals()
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, animals)
            listView.adapter = adapter
        }

        btnUpdate.setOnClickListener {
            val id = etId.text.toString()
            val name = etName.text.toString()
            val species = etSpecies.text.toString()
            val age = etAge.text.toString()
            val enclosure = etEnclosure.text.toString()

            if (id.isNotEmpty()) {
                dbHelper.updateAnimal(id.toInt(), name, species, age.toInt(), enclosure)
                Toast.makeText(this, "Animal Updated", Toast.LENGTH_SHORT).show()
                clearFields()
            } else {
                Toast.makeText(this, "Enter Animal ID to update", Toast.LENGTH_SHORT).show()
            }
        }

        btnDelete.setOnClickListener {
            val id = etId.text.toString()
            if (id.isNotEmpty()) {
                dbHelper.deleteAnimal(id.toInt())
                Toast.makeText(this, "Animal Deleted", Toast.LENGTH_SHORT).show()
                clearFields()
            } else {
                Toast.makeText(this, "Enter Animal ID to delete", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun clearFields() {
        etId.text.clear()
        etName.text.clear()
        etSpecies.text.clear()
        etAge.text.clear()
        etEnclosure.text.clear()
    }
}
