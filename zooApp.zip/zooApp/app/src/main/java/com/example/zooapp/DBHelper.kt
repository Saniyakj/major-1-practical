package com.example.zooapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, "ZooDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "CREATE TABLE animals(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, species TEXT, age INTEGER, enclosure TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS animals")
        onCreate(db)
    }

    fun insertAnimal(name: String, species: String, age: Int, enclosure: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("species", species)
        values.put("age", age)
        values.put("enclosure", enclosure)
        db.insert("animals", null, values)
        db.close()
    }

    fun getAllAnimals(): ArrayList<String> {
        val list = ArrayList<String>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM animals", null)
        if (cursor.moveToFirst()) {
            do {
                val name = cursor.getString(1)
                val species = cursor.getString(2)
                list.add("$name - $species")
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    fun updateAnimal(id: Int, name: String, species: String, age: Int, enclosure: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("species", species)
        values.put("age", age)
        values.put("enclosure", enclosure)
        db.update("animals", values, "id=?", arrayOf(id.toString()))
        db.close()
    }

    fun deleteAnimal(id: Int) {
        val db = writableDatabase
        db.delete("animals", "id=?", arrayOf(id.toString()))
        db.close()
    }
}
