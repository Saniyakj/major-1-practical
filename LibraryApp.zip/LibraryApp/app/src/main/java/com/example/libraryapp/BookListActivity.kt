package com.example.libraryapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity

class BookListActivity : AppCompatActivity() {

    private lateinit var db: DBHelper
    private lateinit var gridBooks: GridView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_list)

        db = DBHelper(this)
        gridBooks = findViewById(R.id.gridBooks)

        val cursor = db.getAllBooks()
        val list = ArrayList<String>()

        while (cursor.moveToNext()) {
            val title = cursor.getString(1)
            val price = cursor.getDouble(3)
            list.add("Title: $title\nPrice: ₹$price")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        gridBooks.adapter = adapter
    }
}
