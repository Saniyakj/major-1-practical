package com.example.libraryapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, "LibraryDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE Books(" +
                    "bookId INTEGER PRIMARY KEY," +
                    "title TEXT," +
                    "author TEXT," +
                    "price REAL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Books")
        onCreate(db)
    }

    fun insertBook(id: Int, title: String, author: String, price: Double): Boolean {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("bookId", id)
        cv.put("title", title)
        cv.put("author", author)
        cv.put("price", price)
        val result = db.insert("Books", null, cv)
        return result != -1L
    }

    fun searchBook(id: Int): Cursor {
        val db = readableDatabase
        return db.rawQuery("SELECT * FROM Books WHERE bookId = ?", arrayOf(id.toString()))
    }

    fun updateBook(id: Int, title: String, author: String, price: Double): Boolean {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("title", title)
        cv.put("author", author)
        cv.put("price", price)
        val result = db.update("Books", cv, "bookId=?", arrayOf(id.toString()))
        return result > 0
    }

    fun deleteBook(id: Int): Boolean {
        val db = writableDatabase
        val result = db.delete("Books", "bookId=?", arrayOf(id.toString()))
        return result > 0
    }

    fun getAllBooks(): Cursor {
        val db = readableDatabase
        return db.rawQuery("SELECT * FROM Books", null)
    }
}
