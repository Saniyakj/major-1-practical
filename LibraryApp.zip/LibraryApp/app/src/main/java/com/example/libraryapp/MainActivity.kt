package com.example.libraryapp

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var db: DBHelper
    private lateinit var etBookId: EditText
    private lateinit var etTitle: EditText
    private lateinit var etAuthor: EditText
    private lateinit var etPrice: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnSearch: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button
    private lateinit var btnViewAll: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DBHelper(this)

        etBookId = findViewById(R.id.etBookId)
        etTitle = findViewById(R.id.etTitle)
        etAuthor = findViewById(R.id.etAuthor)
        etPrice = findViewById(R.id.etPrice)

        btnAdd = findViewById(R.id.btnAdd)
        btnSearch = findViewById(R.id.btnSearch)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnDelete = findViewById(R.id.btnDelete)
        btnViewAll = findViewById(R.id.btnViewAll)

        btnAdd.setOnClickListener {
            val inserted = db.insertBook(
                etBookId.text.toString().toInt(),
                etTitle.text.toString(),
                etAuthor.text.toString(),
                etPrice.text.toString().toDouble()
            )
            Toast.makeText(this, if (inserted) "Book Added" else "Error!", Toast.LENGTH_SHORT).show()
        }

        btnSearch.setOnClickListener {
            val cursor: Cursor = db.searchBook(etBookId.text.toString().toInt())
            if (cursor.moveToFirst()) {
                etTitle.setText(cursor.getString(1))
                etAuthor.setText(cursor.getString(2))
                etPrice.setText(cursor.getDouble(3).toString())
                Toast.makeText(this, "Book Found", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No Book Found", Toast.LENGTH_SHORT).show()
            }
        }

        btnUpdate.setOnClickListener {
            val updated = db.updateBook(
                etBookId.text.toString().toInt(),
                etTitle.text.toString(),
                etAuthor.text.toString(),
                etPrice.text.toString().toDouble()
            )
            Toast.makeText(this, if (updated) "Updated" else "Failed", Toast.LENGTH_SHORT).show()
        }

        btnDelete.setOnClickListener {
            val deleted = db.deleteBook(etBookId.text.toString().toInt())
            Toast.makeText(this, if (deleted) "Deleted" else "Not Found", Toast.LENGTH_SHORT).show()
        }

        btnViewAll.setOnClickListener {
            val intent = Intent(this, BookListActivity::class.java)
            Toast.makeText(this, "Opening Book List...", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }
    }
}
